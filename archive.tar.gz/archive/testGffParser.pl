#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Std;
use Bio::Tools::GFF;


my %opts;
getopts('f:',\%opts); 

&varcheck;

#open (GF,$opts{'f'}) or die "Can't open $opts{'f'}\n";
my $gffIO = Bio::Tools::GFF->new(-file=>$opts{'f'}, -gff_version=>3);
while(my $feature = $gffIO->next_feature()) {
		#print "ref=".ref($feature)."\n";
        #print join(keys %{$feature})."\n";
		print "primtag=".$feature->primary_tag()."\n";
		my @tags = $feature->get_all_tags();
		print "tags=".join("\n",@tags)."\n";
		#my $str = $feature->gff_string;
		#print $str."\n";
		
}
$gffIO->close();


sub varcheck {
	my $errors = "";
	if (!$opts{'f'}){
		$errors .= "-f flag not provided\n";
	}
	elsif(!(-e $opts{'f'})) {
		$errors .= "Can't open $opts{'f'}\n";
	}
	
	if ($errors ne "") {
		print "\n$errors";
		&usage;
	}
}

sub usage{
	
	my $scriptName = $0;
	$scriptName =~ s/\/?.*\///;
	
	print "\nusage: perl $scriptName <-f file>\n";
print <<PRINTTHIS;

I want to print stuff
	
PRINTTHIS
	exit;
}