#!/usr/bin/perl
#########################################################
#  CASHX
#
#  Copyright 2009
#
#  Jason S. Cumbie
#  Christopher M. Sullivan
#  Noah Fahlgren
#  Scott A. Givan
#  Kristin D. Kasschau
#  James C. Carrington
#
#  Department of Botany and Plant Pathology
#  Center for Genome Research and Biocomputing
#  Oregon State University
#  Corvallis, OR 97331
#
#  cashx@cgrb.oregonstate.edu
#
# This program is not free software; you can not redistribute it and/or
# modify it at all.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
#########################################################

use strict;
use warnings;
use FindBin qw($Bin);
use lib "$Bin/..";
use Cwd;
use Carp;
use Getopt::Std;
use CASHX::Configuration;
use CASHX::ReadCASHX;
use POSIX qw( ceil floor);
use GD::Simple;

#########################################################
# Start Variable declarations                           #
#########################################################

my (%opt, $svgFile, $chromNum, $start, $end, $alignment, $conf_file, $refSpecies, $window, $step, %pos, %exon);

getopts('p:c:s:e:C:S:A:w:o:h', \%opt);
&var_check();

my $mercatorConfFile = "$Bin/../conf/mercator.conf";
my $conf = new Configuration(file => $mercatorConfFile);
croak("Error: alignment $alignment does not exist in conf file\n") if(($conf->get($alignment,'species1')) eq -1);
croak("Error: alignment $alignment does not exist in conf file\n") if(($conf->get($alignment,'species2')) eq -1);
my $species1 = $conf->get($alignment,'species1');
my $species2 = $conf->get($alignment,'species2');
my $Conf = new Configuration(file => $conf_file);
my $ReadCASHX1 = new ReadCASHX(conf => $conf_file, species => $species1);
my $ReadCASHX2 = new ReadCASHX(conf => $conf_file, species => $species2);

my $tickLength = 5;
my $iwidth = 1000;
my $track_height = 50;
my $tracks = 9;
my $pad = 10;
my $pad_top = 5;
my $iheight = ($pad_top + ($track_height * $tracks) + $pad);
my $scale = ($iwidth / ($end - $start + 1));
my $read_max = 50;
my $read_min = -50;
my $read_scale = ($track_height / ($read_max - $read_min));
my $y_min = 0.5;
my $y_max = 1;
my $y_scale = ($track_height / ($y_max - $y_min));
my $glyph_height = 5;
my %color;
$color{19} = 'lavender';
$color{20} = 'turquoise';
$color{21} = 'blue';
$color{22} = 'green';
$color{23} = 'fuchsia';
$color{24} = 'red';
$color{25} = 'darkred';
$color{26} = 'black';
$color{27} = 'black';
$color{28} = 'black';
$color{29} = 'black';
$color{30} = 'black';

my $img = GD::Simple->new(($iwidth + $tickLength),$iheight);

#my @color_names = GD::Simple->color_names;
#foreach my $color (@color_names) {
#	print "$color\n";
#}

### Global settings ###
$img->font('Arial');
$img->fontsize(8);
my $current_track_position = 0;
$current_track_position += $pad_top;

#########################################################
# End Variable declarations                             #
#########################################################

#########################################################
# Start Main body of Program                            #
#########################################################

print STDERR " Reading from the mercator table... ";

my (%chromTable, %query);
my $qmin = 0;
my $qmax = 0;
my (@data, $zip, $refPos, $queryPos, $queryChrom);
if ($species1 eq $refSpecies) {
	$zip = $conf->get($alignment,'zipcode1');
	$refPos = $conf->get($alignment,'position1');
	$queryPos = $conf->get($alignment,'position2');
	$queryChrom = $conf->get($alignment,'chrom2');
	my %hash;
	$hash{'chrom'} = $chromNum;
	$hash{'start'} = $start;
	$hash{'end'} = $end;
	$chromTable{$species1} = \%hash;
} else {
	$zip = $conf->get($alignment,'zipcode2');
	$refPos = $conf->get($alignment,'position2');
	$queryPos = $conf->get($alignment,'position1');
	$queryChrom = $conf->get($alignment,'chrom1');
	my %hash;
	$hash{'chrom'} = $chromNum;
	$hash{'start'} = $start;
	$hash{'end'} = $end;
	$chromTable{$species2} = \%hash;
}


my $alyC; #sj
for (my $p = $start; $p <= $end; $p++) {
	$pos{$p} = 0;
	$ReadCASHX1->query("generic_select", "*", "`mercator` WHERE `$zip` LIKE '$chromNum.$p'");
	while (my $row = $ReadCASHX1->results("hash")) {
		$alyC = $row->{$queryChrom}; #sj
		$data[$row->{$refPos}] = $row;
	}
}


my $cycles = (($end - $start + 1) - $window) / $step;
for (my $p = $start; $p <= ($end - $window); $p += $step) {
	if (!defined($data[$p])) {
		$pos{$p} = 0;
		next;
	}
	my $totalCon = 0;
	for (my $i = $p; $i <= ($p + ($window - 1)); $i++) {
		if (defined($data[$i]) && $data[$i]->{'conserved'} == 1) {
			$totalCon++;
		}
	}
	my $percent = ($totalCon / $window);
	if ($percent >= 0.5) {
		$queryChrom = $data[$p]->{$queryChrom} if ($queryChrom =~ /chrom/);
		$query{$p} = $data[$p]->{$queryPos};
		if ($qmin == 0) {
			$qmin = $data[$p]->{$queryPos};
		}
		if ($data[$p]->{$queryPos} < $qmin) {
			$qmin = $data[$p]->{$queryPos};
		}
		if ($data[$p]->{$queryPos} > $qmax) {
			$qmax = $data[$p]->{$queryPos};
		}
		$pos{$p} = $percent;
	} else {
		$pos{$p} = 0;
	}
}

#sj
open (OH,">$svgFile.txt") or die "Can't open $svgFile.txt";
print OH "AlyPos:$alyC:$qmin-$qmax\n";



my ($center, $qmid);
$center = floor(($start + $end) / 2);

for (my $low = $center; $low >= $start; $low--) {
	my $high = (($center - $low) + $center);
	if (defined($query{$low})) {
		$qmid = $query{$low};
		last;
	} elsif (defined($query{$high})) {
		$qmid = $query{$high};
		last;
	}
}
if (!$qmid) {
	print STDERR "\n ERROR: no conserved regions found\n";
	exit 0;
}
my $half_length = (($end - $start + 1) / 2);
#my $center = (($qmax + $qmin) / 2);
$qmin = ceil($qmid - $half_length);
$qmax = ceil($qmid + $half_length);
if ($qmin < 1) {
	$qmin = 1;
}

if ($species1 eq $refSpecies) {
	my %hash;
	$hash{'chrom'} = $queryChrom;
	$hash{'start'} = $qmin;
	$hash{'end'} = $qmax;
	$chromTable{$species2} = \%hash;
} else {
	my %hash;
	$hash{'chrom'} = $queryChrom;
	$hash{'start'} = $qmin;
	$hash{'end'} = $qmax;
	$chromTable{$species1} = \%hash;
}

print STDERR "done\n";


### A. thaliana small RNA track ###
print STDERR " Plotting A. thaliana small RNA histogram... ";
my $ath_file = '/home/mcb/fahlgren/genomes/A.lyrata/mercator/Ath_smallRNA_density.gff';
my $axis = (($track_height / 2) + $current_track_position);
$img->penSize(1,1);
$img->bgcolor('black');
$img->fgcolor('black');
$img->moveTo(0,$axis);
$img->lineTo($iwidth,$axis);
#$img->moveTo($tickLength,$axis);
#$img->lineTo(($iwidth + $tickLength),$axis);
# Draw y-axis
#$img->moveTo($tickLength,$current_track_position);
#$img->lineTo($tickLength,($current_track_position + $track_height));
$img->moveTo($iwidth,$current_track_position);
$img->lineTo($iwidth,($current_track_position + $track_height));
# Top tick
#$img->moveTo(0,$current_track_position);
#$img->lineTo($tickLength,$current_track_position);
$img->moveTo($iwidth,$current_track_position);
$img->lineTo(($iwidth + $tickLength),$current_track_position);
## Middle tick
#$img->moveTo(0,$axis);
#$img->lineTo($tickLength,$axis);
$img->moveTo($iwidth,$axis);
$img->lineTo(($iwidth + $tickLength),$axis);
# Bottom tick
#$img->moveTo(0,($current_track_position + $track_height));
#$img->lineTo($tickLength,($current_track_position + $track_height));
$img->moveTo($iwidth,($current_track_position + $track_height));
$img->lineTo(($iwidth + $tickLength),($current_track_position + $track_height));

$img->penSize(2,2);
open (IN, $ath_file) or die "Cannot open $ath_file: $!\n\n";
while (my $line = <IN>) {
	if ($line =~ /^$chromNum\t/) {
		chomp $line;
		my ($chrom, $source, $type, $start_pos, $end_pos, $reads, $strand, $blank, $note) = split /\t/, $line;
		if ($start_pos >= $chromTable{$species1}->{'start'} && $start_pos <= $chromTable{$species1}->{'end'}) {
			if ($note =~ /sRNA size \[(\d+)\]/) {
				my $color = $color{$1};
				if ($reads > $read_max) {
					$reads = $read_max;
				} elsif ($reads < $read_min) {
					$reads = $read_min;
				}
				my $x = (($start_pos - $chromTable{$species1}->{'start'}) * $scale);
				#my $x = (($start_pos - $chromTable{$species1}->{'start'}) * $scale) + $tickLength;
				my $y;
				if ($strand eq '+') {
					$y = ($axis - ($reads * $read_scale))
				} else {
					$y = ($axis + (abs($reads) * $read_scale));
				}
				$img->bgcolor($color);
				$img->fgcolor($color);
				$img->moveTo($x,$axis);
				$img->lineTo($x,$y);
			}

		}
	}
}
close IN;
$current_track_position += $track_height;
$current_track_position += $pad;
print STDERR "done\n";

### A. thaliana gene model track ###
print STDERR " Plotting A. thaliana gene models... ";
$img->penSize(0.5,0.5);
$img->bgcolor('yellow');
$img->fgcolor('black');
# Draw genes
$ReadCASHX1->query("generic_select", "*", "`features` WHERE `category_id` = 1 AND `chromNum` = $chromTable{$species1}->{'chrom'} AND ((`start` >= $chromTable{$species1}->{'start'} AND `start` <= $chromTable{$species1}->{'end'}) OR (`end` >= $chromTable{$species1}->{'start'} AND `end` <= $chromTable{$species1}->{'end'}))");
while (my $row = $ReadCASHX1->results("hash")) {
	print OH "Atgene=".$row->{'accession'}."\n"; #sj
	if ($row->{'start'} < $chromTable{$species1}->{'start'}) {
		$row->{'start'} = $chromTable{$species1}->{'start'};
	}
	if ($row->{'end'} > $chromTable{$species1}->{'end'}) {
		$row->{'end'} = $chromTable{$species1}->{'end'};
	}
	my $x1 = (($row->{'start'} - $chromTable{$species1}->{'start'}) * $scale);
	my $x2 = (($row->{'end'} - $chromTable{$species1}->{'start'}) * $scale);
	#my $x1 = (($row->{'start'} - $chromTable{$species1}->{'start'}) * $scale) + $tickLength;
	#my $x2 = (($row->{'end'} - $chromTable{$species1}->{'start'}) * $scale) + $tickLength;
	my $offset = 0;
	if ($row->{'strand'} == 1) {
		$offset = 0;
	} else {
		$offset = 20;
	}
	my $y1 = ($current_track_position + $offset);
	my $y2 = ($y1 + $glyph_height);
	
	my ($x3, $y3);
	my $poly = new GD::Polygon;
	if ($x2 - $x1 + 1 >= 5  && $row->{'strand'} == 1) {
		$y3 = ($y1 + ($glyph_height / 2));
		$x3 = $x2;
		$x2 -= 5;
		$poly->addPt($x1,$y1);
		$poly->addPt($x2,$y1);
		$poly->addPt($x3,$y3);
		$poly->addPt($x2,$y2);
		$poly->addPt($x1,$y2);
	} elsif ($x2 - $x1 +1 >= 5 && $row->{'strand'} == -1) {
		$y3 = ($y1 + ($glyph_height / 2));
		$x3 = $x1;
		$x1 += 5;
		$poly->addPt($x3,$y3);
		$poly->addPt($x1,$y1);
		$poly->addPt($x2,$y1);
		$poly->addPt($x2,$y2);
		$poly->addPt($x1,$y2);
	} else {
		$poly->addPt($x1,$y1);
		$poly->addPt($x2,$y1);
		$poly->addPt($x2,$y2);
		$poly->addPt($x1,$y2);
	}
	$img->polygon($poly);
	#$img->rectangle($x1,$y1,$x2,$y2);
	#$img->moveTo($x1,($y1 - 2));
	#$img->string("$row->{'accession'}");
}
$ReadCASHX1->query("generic_select", "*", "`features` WHERE `category_id` = 1 AND `chromNum` = $chromTable{$species1}->{'chrom'} AND $chromTable{$species1}->{'start'} >= `start` AND $chromTable{$species1}->{'end'} <= `end`");
while (my $row = $ReadCASHX1->results("hash")) {
	if ($row->{'start'} < $chromTable{$species1}->{'start'}) {
		$row->{'start'} = $chromTable{$species1}->{'start'};
	}
	if ($row->{'end'} > $chromTable{$species1}->{'end'}) {
		$row->{'end'} = $chromTable{$species1}->{'end'};
	}
	my $x1 = (($row->{'start'} - $chromTable{$species1}->{'start'}) * $scale);
	my $x2 = (($row->{'end'} - $chromTable{$species1}->{'start'}) * $scale);
	#my $x1 = (($row->{'start'} - $chromTable{$species1}->{'start'}) * $scale) + $tickLength;
	#my $x2 = (($row->{'end'} - $chromTable{$species1}->{'start'}) * $scale) + $tickLength;
	my $offset = 0;
	if ($row->{'strand'} == 1) {
		$offset = 0;
	} else {
		$offset = 20;
	}
	my $y1 = ($current_track_position + $offset);
	my $y2 = ($y1 + $glyph_height);
	
	my ($x3, $y3);
	my $poly = new GD::Polygon;
	if ($x2 - $x1 + 1 >= 5  && $row->{'strand'} == 1) {
		$y3 = ($y1 + ($glyph_height / 2));
		$x3 = $x2;
		$x2 -= 5;
		$poly->addPt($x1,$y1);
		$poly->addPt($x2,$y1);
		$poly->addPt($x3,$y3);
		$poly->addPt($x2,$y2);
		$poly->addPt($x1,$y2);
	} elsif ($x2 - $x1 +1 >= 5 && $row->{'strand'} == -1) {
		$y3 = ($y1 + ($glyph_height / 2));
		$x3 = $x1;
		$x1 += 5;
		$poly->addPt($x3,$y3);
		$poly->addPt($x1,$y1);
		$poly->addPt($x2,$y1);
		$poly->addPt($x2,$y2);
		$poly->addPt($x1,$y2);
	} else {
		$poly->addPt($x1,$y1);
		$poly->addPt($x2,$y1);
		$poly->addPt($x2,$y2);
		$poly->addPt($x1,$y2);
	}
	$img->polygon($poly);
	#$img->rectangle($x1,$y1,$x2,$y2);
}

# Draw exons
$img->bgcolor('blue');
$img->fgcolor('blue');

$ReadCASHX1->query("generic_select", "*", "`features` WHERE `category_id` = 4 AND `chromNum` = $chromTable{$species1}->{'chrom'} AND ((`start` >= $chromTable{$species1}->{'start'} AND `start` <= $chromTable{$species1}->{'end'}) OR (`end` >= $chromTable{$species1}->{'start'} AND `end` <= $chromTable{$species1}->{'end'}))");
while (my $row = $ReadCASHX1->results("hash")) {
	if ($row->{'start'} < $chromTable{$species1}->{'start'}) {
		$row->{'start'} = $chromTable{$species1}->{'start'};
	}
	if ($row->{'end'} > $chromTable{$species1}->{'end'}) {
		$row->{'end'} = $chromTable{$species1}->{'end'};
	}
	my $x1 = (($row->{'start'} - $chromTable{$species1}->{'start'}) * $scale);
	my $x2 = (($row->{'end'} - $chromTable{$species1}->{'start'}) * $scale);
	#my $x1 = (($row->{'start'} - $chromTable{$species1}->{'start'}) * $scale) + $tickLength;
	#my $x2 = (($row->{'end'} - $chromTable{$species1}->{'start'}) * $scale) + $tickLength;
	my $offset = 0;
	if ($row->{'strand'} == 1) {
		$offset = 0;
	} else {
		$offset = 20;
	}
	my $y1 = (($current_track_position + $offset) + 10);
	my $y2 = ($y1 + $glyph_height);
	$img->rectangle($x1,$y1,$x2,$y2);
	for ($row->{'start'}..$row->{'end'}) {
		$exon{$_} = 1;
	}
}
$ReadCASHX1->query("generic_select", "*", "`features` WHERE `category_id` = 4 AND `chromNum` = $chromTable{$species1}->{'chrom'} AND $chromTable{$species1}->{'start'} >= `start` AND $chromTable{$species1}->{'end'} <= `end`");
while (my $row = $ReadCASHX1->results("hash")) {
	if ($row->{'start'} < $chromTable{$species1}->{'start'}) {
		$row->{'start'} = $chromTable{$species1}->{'start'};
	}
	if ($row->{'end'} > $chromTable{$species1}->{'end'}) {
		$row->{'end'} = $chromTable{$species1}->{'end'};
	}
	my $x1 = (($row->{'start'} - $chromTable{$species1}->{'start'}) * $scale);
	my $x2 = (($row->{'end'} - $chromTable{$species1}->{'start'}) * $scale);
	#my $x1 = (($row->{'start'} - $chromTable{$species1}->{'start'}) * $scale) + $tickLength;
	#my $x2 = (($row->{'end'} - $chromTable{$species1}->{'start'}) * $scale) + $tickLength;
	my $offset = 0;
	if ($row->{'strand'} == 1) {
		$offset = 0;
	} else {
		$offset = 20;
	}
	my $y1 = (($current_track_position + $offset) + 10);
	my $y2 = ($y1 + $glyph_height);
	$img->rectangle($x1,$y1,$x2,$y2);
	for ($row->{'start'}..$row->{'end'}) {
		$exon{$_} = 1;
	}
}

$current_track_position += 20;
print STDERR "done\n";

### A. thaliana transposable element track ###
print STDERR " Plotting A. thaliana TEs... ";

$img->bgcolor('green');
$img->fgcolor('green');
$ReadCASHX1->query("generic_select", "*", "`features` WHERE `category_id` >= 18 AND `category_id` <= 35 AND `chromNum` = $chromTable{$species1}->{'chrom'} AND $chromTable{$species1}->{'start'} <= `start` AND $chromTable{$species1}->{'end'} >= `end`");
while (my $row = $ReadCASHX1->results("hash")) {
	if ($row->{'start'} < $chromTable{$species1}->{'start'}) {
		$row->{'start'} = $chromTable{$species1}->{'start'};
	}
	if ($row->{'end'} > $chromTable{$species1}->{'end'}) {
		$row->{'end'} = $chromTable{$species1}->{'end'};
	}
	my $x1 = (($row->{'start'} - $chromTable{$species1}->{'start'}) * $scale);
	my $x2 = (($row->{'end'} - $chromTable{$species1}->{'start'}) * $scale);
	#my $x1 = (($row->{'start'} - $chromTable{$species1}->{'start'}) * $scale) + $tickLength;
	#my $x2 = (($row->{'end'} - $chromTable{$species1}->{'start'}) * $scale) + $tickLength;
	my $y1 = ($current_track_position + 20);
	my $y2 = ($y1 + $glyph_height);
	$img->rectangle($x1,$y1,$x2,$y2);
}

$current_track_position += ($track_height / 2);
$current_track_position += $pad;
print STDERR "done\n";

### A. thaliana vs A. lyrata conservation track ###
print STDERR " Plotting conservation... ";
$img->penSize(1,1);
$img->bgcolor('black');
$img->fgcolor('black');

# Draw y-axes
my $connectHeight = $track_height + ($track_height / 2);
my $lowerHeight = $connectHeight + $track_height;

# Top
#$img->moveTo($tickLength,$current_track_position);
#$img->lineTo($tickLength,($current_track_position + $track_height));
$img->moveTo($iwidth,$current_track_position);
$img->lineTo($iwidth,($current_track_position + $track_height));
# Top tick
#$img->moveTo(0,$current_track_position);
#$img->lineTo($tickLength,$current_track_position);
$img->moveTo($iwidth,$current_track_position);
$img->lineTo(($iwidth + $tickLength),$current_track_position);
# Middle tick
#$img->moveTo(0,$axis);
#$img->lineTo($tickLength,$axis);
$img->moveTo($iwidth,(($track_height / 2) + $current_track_position));
$img->lineTo(($iwidth + $tickLength),(($track_height / 2) + $current_track_position));
# Bottom tick
#$img->moveTo(0,($current_track_position + $track_height));
#$img->lineTo($tickLength,($current_track_position + $track_height));
$img->moveTo($iwidth,($current_track_position + $track_height));
$img->lineTo(($iwidth + $tickLength),($current_track_position + $track_height));

# Bottom
#$img->moveTo($tickLength, ($current_track_position + $track_height + $track_height));
#$img->lineTo($tickLength,($current_track_position + $track_height + $track_height + $track_height));
$img->moveTo($iwidth, ($current_track_position + $connectHeight));
$img->lineTo($iwidth,($current_track_position + $lowerHeight));
# Top tick
#$img->moveTo(0,$current_track_position);
#$img->lineTo($tickLength,$current_track_position);
$img->moveTo($iwidth,($current_track_position + $connectHeight));
$img->lineTo(($iwidth + $tickLength),($current_track_position + $connectHeight));
# Middle tick
#$img->moveTo(0,$axis);
#$img->lineTo($tickLength,$axis);
$img->moveTo($iwidth,(($track_height / 2) + $current_track_position + $connectHeight));
$img->lineTo(($iwidth + $tickLength),(($track_height / 2) + $current_track_position + $connectHeight));
# Bottom tick
#$img->moveTo(0,($current_track_position + $track_height));
#$img->lineTo($tickLength,($current_track_position + $track_height));
$img->moveTo($iwidth,($current_track_position + $lowerHeight));
$img->lineTo(($iwidth + $tickLength),($current_track_position + $lowerHeight));


if ($scale > 0.5) {
	#$img->penSize((0.55 + ($scale / 2)),(0.55 + ($scale / 2)));
	$img->penSize(1,1);
} else {
	$img->penSize(0.5,0.5);
}

for (my $p = $start; $p <= $end; $p++) {
	next if ($pos{$p} == 0);
	if (defined($exon{$p})) {
		$img->bgcolor('black');
		$img->fgcolor('black');
	} else {
		$img->bgcolor('gray');
		$img->fgcolor('gray');
	}
	my $x1 = (($p - $start) * $scale);
	#my $x1 = (($p - $start) * $scale) + $tickLength;
	my $y = (($pos{$p} - $y_min) * $y_scale);
	$y = (($track_height + $current_track_position) - $y);
	$img->moveTo($x1,($track_height + $current_track_position));
	$img->lineTo($x1,$y);

	next if (!$query{$p});
	$x1 = (($query{$p} - $qmin) * $scale);
	#$x1 = (($query{$p} - $qmin) * $scale) + $tickLength;
	my $x2 = (($p - $start) * $scale);
	#my $x2 = (($p - $start) * $scale) + $tickLength;
	$img->moveTo($x2,($current_track_position + $track_height));
	$img->lineTo($x1,($current_track_position + $connectHeight));

	next if ($x1 > $iwidth);
	$y = (($pos{$p} - $y_min) * $y_scale);
	$img->moveTo($x1,($current_track_position + $connectHeight));
	$img->lineTo($x1,($y + $current_track_position + $connectHeight));
}
$img->penSize(1,1);
$img->bgcolor('black');
$img->fgcolor('black');
$img->moveTo(0,($track_height + $current_track_position));
$img->lineTo($iwidth,($track_height + $current_track_position));
$img->moveTo(0,($current_track_position + $connectHeight));
$img->lineTo($iwidth,($current_track_position + $connectHeight));
#$img->moveTo($tickLength,($track_height + $current_track_position));
#$img->lineTo(($iwidth + $tickLength),($track_height + $current_track_position));
#$img->moveTo($tickLength,($current_track_position + ($track_height * 2)));
#$img->lineTo(($iwidth + $tickLength),($current_track_position + ($track_height * 2)));
#$current_track_position += $track_height;
#$current_track_position += ($track_height);
$current_track_position += $lowerHeight;

print STDERR "done\n";

### A. lyrata transposable element track ###
print STDERR " Plotting A. lyrata TEs... ";
$img->penSize(0.5,0.5);
#$current_track_position += $track_height;
$img->bgcolor('green');
$img->fgcolor('green');

$ReadCASHX2->query("generic_select", "*", "`features` WHERE `category_id` >= 18 AND `category_id` <= 40 AND `chromNum` = $chromTable{$species2}->{'chrom'} AND $chromTable{$species2}->{'start'} <= `start` AND $chromTable{$species2}->{'end'} >= `end`");
while (my $row = $ReadCASHX2->results("hash")) {
	if ($row->{'start'} < $chromTable{$species2}->{'start'}) {
		$row->{'start'} = $chromTable{$species2}->{'start'};
	}
	if ($row->{'end'} > $chromTable{$species2}->{'end'}) {
		$row->{'end'} = $chromTable{$species2}->{'end'};
	}
	my $x1 = (($row->{'start'} - $chromTable{$species2}->{'start'}) * $scale);
	my $x2 = (($row->{'end'} - $chromTable{$species2}->{'start'}) * $scale);
	#my $x1 = (($row->{'start'} - $chromTable{$species2}->{'start'}) * $scale) + $tickLength;
	#my $x2 = (($row->{'end'} - $chromTable{$species2}->{'start'}) * $scale) + $tickLength;
	my $y1 = ($current_track_position + 10);
	my $y2 = ($y1 + $glyph_height);
	$img->rectangle($x1,$y1,$x2,$y2);
}

$current_track_position += 20;

### A. lyrata gene models track ###

# Draw exons
$img->bgcolor('blue');
$img->fgcolor('blue');

$ReadCASHX2->query("generic_select", "*", "`features` WHERE `category_id` = 4 AND `chromNum` = $chromTable{$species2}->{'chrom'} AND ((`start` >= $chromTable{$species2}->{'start'} AND `start` <= $chromTable{$species2}->{'end'}) OR (`end` >= $chromTable{$species2}->{'start'} AND `end` <= $chromTable{$species2}->{'end'}))");
while (my $row = $ReadCASHX2->results("hash")) {
	if ($row->{'start'} < $chromTable{$species2}->{'start'}) {
		$row->{'start'} = $chromTable{$species2}->{'start'};
	}
	if ($row->{'end'} > $chromTable{$species2}->{'end'}) {
		$row->{'end'} = $chromTable{$species2}->{'end'};
	}
	my $x1 = (($row->{'start'} - $chromTable{$species2}->{'start'}) * $scale);
	my $x2 = (($row->{'end'} - $chromTable{$species2}->{'start'}) * $scale);
	#my $x1 = (($row->{'start'} - $chromTable{$species2}->{'start'}) * $scale) + $tickLength;
	#my $x2 = (($row->{'end'} - $chromTable{$species2}->{'start'}) * $scale) + $tickLength;
	my $offset = 0;
	if ($row->{'strand'} == 1) {
		$offset = 20;
	} else {
		$offset = 0;
	}
	my $y1 = ($current_track_position + $offset);
	my $y2 = ($y1 + $glyph_height);
	$img->rectangle($x1,$y1,$x2,$y2);
}

$ReadCASHX2->query("generic_select", "*", "`features` WHERE `category_id` = 4 AND `chromNum` = $chromTable{$species2}->{'chrom'} AND $chromTable{$species2}->{'start'} >= `start` AND $chromTable{$species2}->{'end'} <= `end`");
while (my $row = $ReadCASHX2->results("hash")) {
	if ($row->{'start'} < $chromTable{$species2}->{'start'}) {
		$row->{'start'} = $chromTable{$species2}->{'start'};
	}
	if ($row->{'end'} > $chromTable{$species2}->{'end'}) {
		$row->{'end'} = $chromTable{$species2}->{'end'};
	}
	my $x1 = (($row->{'start'} - $chromTable{$species2}->{'start'}) * $scale);
	my $x2 = (($row->{'end'} - $chromTable{$species2}->{'start'}) * $scale);
	#my $x1 = (($row->{'start'} - $chromTable{$species2}->{'start'}) * $scale) + $tickLength;
	#my $x2 = (($row->{'end'} - $chromTable{$species2}->{'start'}) * $scale) + $tickLength;
	my $offset = 0;
	if ($row->{'strand'} == 1) {
		$offset = 20;
	} else {
		$offset = 0;
	}
	my $y1 = ($current_track_position + $offset);
	my $y2 = ($y1 + $glyph_height);
	$img->rectangle($x1,$y1,$x2,$y2);
}

$img->bgcolor('yellow');
$img->fgcolor('black');
# Draw genes
$ReadCASHX2->query("generic_select", "*", "`features` WHERE `category_id` = 1 AND `chromNum` = $chromTable{$species2}->{'chrom'} AND ((`start` >= $chromTable{$species2}->{'start'} AND `start` <= $chromTable{$species2}->{'end'}) OR (`end` >= $chromTable{$species2}->{'start'} AND `end` <= $chromTable{$species2}->{'end'}))");
while (my $row = $ReadCASHX2->results("hash")) {
	print OH "Alygene=".$row->{'accession'}."\n";  #sj
	if ($row->{'start'} < $chromTable{$species2}->{'start'}) {
		$row->{'start'} = $chromTable{$species2}->{'start'};
	}
	if ($row->{'end'} > $chromTable{$species2}->{'end'}) {
		$row->{'end'} = $chromTable{$species2}->{'end'};
	}
	my $x1 = (($row->{'start'} - $chromTable{$species2}->{'start'}) * $scale);
	my $x2 = (($row->{'end'} - $chromTable{$species2}->{'start'}) * $scale);
	#my $x1 = (($row->{'start'} - $chromTable{$species2}->{'start'}) * $scale) + $tickLength;
	#my $x2 = (($row->{'end'} - $chromTable{$species2}->{'start'}) * $scale) + $tickLength;
	my $offset = 0;
	if ($row->{'strand'} == 1) {
		$offset = 20;
	} else {
		$offset = 0;
	}
	my $y1 = (($current_track_position + $offset) + 10);
	my $y2 = ($y1 + $glyph_height);
	
	my ($x3, $y3);
	my $poly = new GD::Polygon;
	if ($x2 - $x1 + 1 >= 5  && $row->{'strand'} == 1) {
		$y3 = ($y1 + ($glyph_height / 2));
		$x3 = $x2;
		$x2 -= 5;
		$poly->addPt($x1,$y1);
		$poly->addPt($x2,$y1);
		$poly->addPt($x3,$y3);
		$poly->addPt($x2,$y2);
		$poly->addPt($x1,$y2);
	} elsif ($x2 - $x1 +1 >= 5 && $row->{'strand'} == -1) {
		$y3 = ($y1 + ($glyph_height / 2));
		$x3 = $x1;
		$x1 += 5;
		$poly->addPt($x3,$y3);
		$poly->addPt($x1,$y1);
		$poly->addPt($x2,$y1);
		$poly->addPt($x2,$y2);
		$poly->addPt($x1,$y2);
	} else {
		$poly->addPt($x1,$y1);
		$poly->addPt($x2,$y1);
		$poly->addPt($x2,$y2);
		$poly->addPt($x1,$y2);
	}
	$img->polygon($poly);
	#$img->rectangle($x1,$y1,$x2,$y2);
}
$ReadCASHX2->query("generic_select", "*", "`features` WHERE `category_id` = 1 AND `chromNum` = $chromTable{$species2}->{'chrom'} AND $chromTable{$species2}->{'start'} >= `start` AND $chromTable{$species2}->{'end'} <= `end`");
while (my $row = $ReadCASHX2->results("hash")) {
	if ($row->{'start'} < $chromTable{$species2}->{'start'}) {
		$row->{'start'} = $chromTable{$species2}->{'start'};
	}
	if ($row->{'end'} > $chromTable{$species2}->{'end'}) {
		$row->{'end'} = $chromTable{$species2}->{'end'};
	}
	my $x1 = (($row->{'start'} - $chromTable{$species2}->{'start'}) * $scale);
	my $x2 = (($row->{'end'} - $chromTable{$species2}->{'start'}) * $scale);
	#my $x1 = (($row->{'start'} - $chromTable{$species2}->{'start'}) * $scale) + $tickLength;
	#my $x2 = (($row->{'end'} - $chromTable{$species2}->{'start'}) * $scale) + $tickLength;
	my $offset = 0;
	if ($row->{'strand'} == 1) {
		$offset = 20;
	} else {
		$offset = 0;
	}
	my $y1 = (($current_track_position + $offset) + 10);
	my $y2 = ($y1 + $glyph_height);
	
	my ($x3, $y3);
	my $poly = new GD::Polygon;
	if ($x2 - $x1 + 1 >= 5  && $row->{'strand'} == 1) {
		$y3 = ($y1 + ($glyph_height / 2));
		$x3 = $x2;
		$x2 -= 5;
		$poly->addPt($x1,$y1);
		$poly->addPt($x2,$y1);
		$poly->addPt($x3,$y3);
		$poly->addPt($x2,$y2);
		$poly->addPt($x1,$y2);
	} elsif ($x2 - $x1 +1 >= 5 && $row->{'strand'} == -1) {
		$y3 = ($y1 + ($glyph_height / 2));
		$x3 = $x1;
		$x1 += 5;
		$poly->addPt($x3,$y3);
		$poly->addPt($x1,$y1);
		$poly->addPt($x2,$y1);
		$poly->addPt($x2,$y2);
		$poly->addPt($x1,$y2);
	} else {
		$poly->addPt($x1,$y1);
		$poly->addPt($x2,$y1);
		$poly->addPt($x2,$y2);
		$poly->addPt($x1,$y2);
	}
	$img->polygon($poly);
	#$img->rectangle($x1,$y1,$x2,$y2);
}

$current_track_position += 30;
$current_track_position += $pad;
print STDERR "done\n";

### A. lyrata small RNA track ###
print STDERR " Plotting A. lyrata small RNA histogram... ";
my $aly_file = '/home/mcb/fahlgren/genomes/A.lyrata/mercator/Aly_smallRNA_density.gff';
$axis = (($track_height / 2) + $current_track_position);
$img->penSize(1,1);
$img->bgcolor('black');
$img->fgcolor('black');
$img->moveTo(0,$axis);
$img->lineTo($iwidth,$axis);
#$img->moveTo($tickLength,$axis);
#$img->lineTo(($iwidth + $tickLength),$axis);
# Draw y-axis
#$img->moveTo($tickLength,$current_track_position);
#$img->lineTo($tickLength,($current_track_position + $track_height));
$img->moveTo($iwidth,$current_track_position);
$img->lineTo($iwidth,($current_track_position + $track_height));
# Top tick
#$img->moveTo(0,$current_track_position);
#$img->lineTo($tickLength,$current_track_position);
$img->moveTo($iwidth,$current_track_position);
$img->lineTo(($iwidth + $tickLength),$current_track_position);
# Middle tick
#$img->moveTo(0,$axis);
#$img->lineTo($tickLength,$axis);
$img->moveTo($iwidth,$axis);
$img->lineTo(($iwidth + $tickLength),$axis);
# Bottom tick
#$img->moveTo(0,($current_track_position + $track_height));
#$img->lineTo($tickLength,($current_track_position + $track_height));
$img->moveTo($iwidth,($current_track_position + $track_height));
$img->lineTo(($iwidth + $tickLength),($current_track_position + $track_height));

$img->penSize(2,2);
open (IN, $aly_file) or die "Cannot open $aly_file: $!\n\n";
while (my $line = <IN>) {
	if ($line =~ /^$chromTable{$species2}->{'chrom'}\t/) {
		chomp $line;
		my ($chrom, $source, $type, $start_pos, $end_pos, $reads, $strand, $blank, $note) = split /\t/, $line;
		if ($start_pos >= $chromTable{$species2}->{'start'} && $start_pos <= $chromTable{$species2}->{'end'}) {
			if ($note =~ /sRNA size \[(\d+)\]/) {
				my $color = $color{$1};
				if ($reads > $read_max) {
					$reads = $read_max;
				} elsif ($reads < $read_min) {
					$reads = $read_min;
				}
				my $x = (($start_pos - $chromTable{$species2}->{'start'}) * $scale);
				#my $x = (($start_pos - $chromTable{$species2}->{'start'}) * $scale) + $tickLength;
				my $y;
				if ($strand eq '+') {
					$y = ($axis - ($reads * $read_scale))
				} else {
					$y = ($axis + (abs($reads) * $read_scale));
				}
				$img->bgcolor($color);
				$img->fgcolor($color);
				$img->moveTo($x,$axis);
				$img->lineTo($x,$y);
			}

		}
	}
}
close IN;
$current_track_position += $track_height;
$current_track_position += $pad;
print STDERR "done\n";


### Create images ###
open (OUT, ">$svgFile.png") or die "Cannot open $svgFile.png: $!\n\n";
binmode(OUT);
#print OUT $img->svg();
print OUT $img->png(0);
close OUT;

#`convert $svgFile.svg $svgFile.pdf`;
#`convert -density 800x600 $outfile.svg $outfile.pdf`;
close OH;
exit;

#########################################################
# Start Subroutines                                     #
#########################################################

#########################################################
# Start of Subroutine "round"                           #
#########################################################

sub round {
	my $num = shift;
	if ($num =~ /\d+\.(\d)/) {
		if ($1 >= 5) {
			$num = ceil($num);
		} else {
			$num = floor($num);
		}
	}
	return $num;
}

#########################################################
# End of Subroutine "round"                             #
#########################################################

#########################################################
# Start of Varriable Check Subroutine "var_check"       #
#########################################################

sub var_check {
	if ($opt{'p'}) {
		$svgFile = $opt{'p'};
	} else {
		print STDERR "  ERROR: Plot file prefix not provided.\n\n";
		&var_error();
	}
	if ($opt{'c'}) {
		$chromNum = $opt{'c'};
	} else {
		print STDERR "  ERROR: Chromosome number not provided.\n\n";
		&var_error();
	}
	if ($opt{'s'}) {
		$start = $opt{'s'};
	} else {
		print STDERR "  ERROR: Start coordinate not provided.\n\n";
		&var_error();
	}
	if ($opt{'e'}) {
		$end = $opt{'e'};
	} else {
		print STDERR "  ERROR: End coordinate not provided.\n\n";
		&var_error();
	}
	if ($opt{'A'}) {
		$alignment = $opt{'A'};
	} else {
		print STDERR "  ERROR: An alignment code was not provided.\n\n";
		&var_error();
	}
	if ($opt{'C'}) {
		$conf_file = $opt{'C'};
	} else {
		print STDERR "  ERROR: Conf file not provided.\n";
		&var_error();
	}
	if ($opt{'S'}) {
		$refSpecies = $opt{'S'};
	} else {
		print STDERR " ERROR: Reference species not provided.\n";
		&var_error();
	}
	if ($opt{'w'}) {
		$window = $opt{'w'};
	} else {
		$window = 100;
	}
	if ($opt{'o'}) {
		$step = $opt{'o'};
	} else {
		$step = 1;
	}
	if ($opt{'h'}) {
		&var_error();
	}
}

#########################################################
# End of Varriable Check Subroutine "var_check"         #
#########################################################

#########################################################
# Start of Varriable error Subroutine "var_error"       #
#########################################################

sub var_error {
	print STDERR "\n  Description:\n";
	print STDERR "  This script will create a conservation plot of orthologous regions between two genomes.\n";
	print STDERR "  Usage:\n";
	print STDERR " 	mercatorPlot.pl -C <conf_file> -S <ref_species> -p <plot_file_prefix> -c <chrom> -s <start> -e <end> -A <alignment>\n";
	print STDERR "\n\n";
	print STDERR "  -C   The CASHX configuration file.\n";
	print STDERR "\n";
	print STDERR "  -S   The plotting reference species.\n";
	print STDERR "               example: -S A_THALIANA\n";
	print STDERR "\n";
	print STDERR "  -A   The alignment code from 'mercator.conf'.\n";
	print STDERR "               example: -A ATH_ALY\n";
	print STDERR "\n";
	print STDERR "  -p   The plot file prefix.\n";
	print STDERR "\n";
	print STDERR "  -c   The reference species chromosome.\n";
	print STDERR "\n";
	print STDERR "  -s   The reference species start coordinate.\n";
	print STDERR "\n";
	print STDERR "  -e   The reference species end coordinate.\n";
	print STDERR "\n";
	print STDERR "  -w   The window size used to calculate conservation. (DEFAULT = 100)\n";
	print STDERR "\n";
	print STDERR "  -o   The scroll step size. (DEFAULT = 1)\n";
	print STDERR "\n";
	print STDERR "  -h   Print this menu.\n";
	print STDERR "\n\n\n";
	exit 0;
}

#########################################################
# End of Varriable error Subroutine "var_error"         #
#########################################################
