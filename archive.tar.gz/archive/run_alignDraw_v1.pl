#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Std;

my %opts;
getopts('p:t:o:h',\%opts); 

&varcheck;

open (PF,$opts{'p'}) or die "Can't open $opts{'p'}\n";
my @params = <PF>;
close PF;

open (TF,$opts{'t'}) or die "Can't open $opts{'t'}\n";
my @template = <TF>;
close TF;



my $outDir = $opts{'o'};
$outDir =~ s/\/$//;
	

foreach my $pLine (@params){
	chomp $pLine;
	my ($athParam,$alyParam) = split("\t",$pLine);
	my $outFile = "$outDir/$athParam--$alyParam.conf";
	open (OF,">$outFile") or die "Can't open $outFile\n";
	my %subList = ('REF1_NAME' => $athParam, 'REF2_NAME' => $alyParam);
	$subList{'ALIGNMENT_SOURCE'} = "/raid3/carrington/jogdeos/carrington/ppr/arabPPRanalys/PPRalignments/$athParam--$alyParam\_align";
	
	#print "athparam=$athParam,alyparam=$alyParam\n";
	my @templateLines = @template;
	foreach my $tLine (@templateLines){
		foreach my $sl (keys %subList){
			$tLine =~ s/$sl/$subList{$sl}/;
		}
		print OF $tLine;
	}
	
	
	close OF;

}


sub varcheck {
	&usage if ($opts{'h'});
	my $errors = "";
	if (!$opts{'p'}){
		$errors .= "You have not provided a value for the -p flag\n";
	}
	elsif(!(-e $opts{'p'})) {
		$errors .= "Can't open $opts{'p'}\n";
	}
	
	if (!$opts{'t'}){
		$errors .= "You have not provided a value for the -t flag\n";
	}
	elsif(!(-e $opts{'t'})) {
		$errors .= "Can't open $opts{'t'}\n";
	}
	if (!$opts{'o'}){
		$errors .= "You have not provided a value for the -o flag\n";
	}
	elsif(!(-d $opts{'o'})) {
		$errors .= "The input you provided for -o is not a directory\n";
	}
	if ($errors ne "") {
		print "\n$errors";
		&usage;
	}
}

sub usage{
	
	my $scriptName = $0;
	$scriptName =~ s/\/?.*\///;
	
	print "\nusage: perl $scriptName <-p file> <-t file> <o dir>\n";
print <<PRINTTHIS;

Creates conf files for use with alignDraw.

-p tab delimted list of paramters.  2 columns, the first for REF1 and 2nd for REF2.
-t template for the conf file
-o output direcotry for conf files
	
PRINTTHIS
	exit;
}