#!/usr/bin/perl
#########################################################
#  CASHX
#
#  Copyright 2009
#
#  Jason S. Cumbie
#  Christopher M. Sullivan
#  Noah Fahlgren
#  Scott A. Givan
#  Kristin D. Kasschau
#  James C. Carrington
#
#  Department of Botany and Plant Pathology
#  Center for Genome Research and Biocomputing
#  Oregon State University
#  Corvallis, OR 97331
#
#  cashx@cgrb.oregonstate.edu
#
# This program is not free software; you can not redistribute it and/or
# modify it at all.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
#########################################################
# To do list:
# -ability to use multiple filters on same gff file (e.g. by source and type would let you filter for CDS and PPR)
# -ability to handle other combinations of alignments (e.g. transcript is genomic and feature is algined to spliced transcript)
#
#########################################################

use strict;
use warnings;
use lib '/mcclintock/jogdeos/programs/software/CASHX_2.0';
use lib '/home/cgrb/cgrblib-dev/perl5';
use Cwd;
use Carp;
use Getopt::Std;
use CASHX::Configuration;
use CASHX::ReadCASHX;
use POSIX qw( ceil floor);
use GD::Simple;
use Config::Tiny;



#########################################################
# Start Variable declarations                           #
#########################################################



my (%opt, $svgFile, $chromNum, $alignment, $conf_file, $refSpecies, $window, $step, %pos, %exon);
getopts('L:A:o:', \%opt);

&var_check();


$alignment = "ATH_ALY";
my $mercatorConfFile = "/mcclintock/jogdeos/programs/software/CASHX_2.0/conf/mercator.conf";
my $mercConf = new Configuration(file => $mercatorConfFile);
$conf_file = "/mcclintock/jogdeos/programs/software/CASHX_2.0/conf/CASHX.conf";
my $width=2000;

my $alignConf = Config::Tiny->new;
$alignConf = Config::Tiny->read($opt{'L'});
croak("Error: alignment $alignment does not exist in conf file\n") if(($mercConf->get($alignment,'species1')) eq -1);
croak("Error: alignment $alignment does not exist in conf file\n") if(($mercConf->get($alignment,'species2')) eq -1);
my $species1 = $mercConf->get($alignment,'species1');
my $species2 = $mercConf->get($alignment,'species2');
my $Conf = new Configuration(file => $conf_file);
my $ReadCASHX1 = new ReadCASHX(conf => $conf_file, species => $species1);
my $ReadCASHX2 = new ReadCASHX(conf => $conf_file, species => $species2);

#get tracks and track order from alignConfig file
my $trackConfigs;
my @trackOrder;
foreach my $c (keys %{$alignConf}){
	if ($c ne "_"){
		$trackConfigs->{$c} = $alignConf->{$c};
		push(@trackOrder,$c);
	}
}
@trackOrder = sort {$trackConfigs->{$a}->{'trackOrder'}<=>$trackConfigs->{$b}->{'trackOrder'}} @trackOrder;

my $params = $alignConf->{'_'};
my $alignType = $params->{'alignType'};
my $alignFile = $opt{'A'};
my $tickLength = $params->{'tickLength'};
my $iwidth = $params->{'iwidth'};
my $track_height = $params->{'track_height'};
my $pad = $params->{'pad'};
my $pad_top = $params->{'pad_top'};
my $iheight = ($pad_top + ($track_height * @trackOrder) + $pad);
my $scale = ($iwidth / ($width + 1));
my $read_max = $params->{'read_max'};
my $read_min = $params->{'read_min'};
my $read_scale = ($track_height / ($read_max - $read_min));
my $y_min = $params->{'y_min'};
my $y_max = $params->{'y_max'};
my $y_scale = ($track_height / ($y_max - $y_min));
my $glyph_height = $params->{'glyph_height'};
my %color;
$color{19} = 'lavender';
$color{20} = 'turquoise';
$color{21} = 'blue';
$color{22} = 'green';
$color{23} = 'fuchsia';
$color{24} = 'red';
$color{25} = 'darkred';
$color{26} = 'black';
$color{27} = 'black';
$color{28} = 'black';
$color{29} = 'black';
$color{30} = 'black';
my %gffFields = ('seqid'=>0,'source'=>1,'type'=>2,'start'=>3,'end'=>4,
				 'score'=>5,'strand'=>6,'phase'=>7,'attribs'=>8);
my @gffFields = qw (seqid source type start end score strand phase attribs);
my $genomeToTranscriptMap;


#########################################################
# End Variable declarations                             #
#########################################################

#########################################################
# Start Main body of Program                            #
#########################################################


#retrieve track data from various sources
my @refTracks = grep (/REF/,keys %{$trackConfigs});
my @plotTracks = grep (!/REF/,keys %{$trackConfigs});
my $trackData = &getData($trackConfigs,\@refTracks);
my $tempData = &getData($trackConfigs,\@plotTracks);
while (my($key, $value) = each %{$tempData}){
	$trackData->{$key} = $value;
}


my $img = GD::Simple->new(($iwidth + $tickLength),$iheight);
$img->font('Arial');
$img->fontsize(8);
my $current_track_position = 0;

my ($alignMatrix,$alignRef,$alignLen) = &getAlignMatrix();
my $ref1AlignPad= 0;
my $ref2AlignPad = 0;
my $ref1Len = $trackData->{'REF1'}->{'length'};
my $ref2Len = $trackData->{'REF2'}->{'length'};
my @ordRef1Pos = sort{$a<=>$b} keys %{$alignMatrix};
my @ordRef2Pos;
foreach my $k (keys %{$alignMatrix}){
	push (@ordRef2Pos,$alignMatrix->{$k}->{'pos'});
}
@ordRef2Pos = sort {$a<=>$b} @ordRef2Pos;


#use the average of the aligned positions to shift one of the references so that the
#alignment is straighter.

#my $ref1Mid =$ordRef1Pos[0] + (.5*($ordRef1Pos[@ordRef1Pos-1]-$ordRef1Pos[0]));
#my $ref2Mid =$ordRef2Pos[0] + (.5*($ordRef2Pos[@ordRef2Pos-1]-$ordRef2Pos[0]));

my ($ref1mid, $ref2mid) = (0,0);
$ref1mid += $_ foreach @ordRef1Pos;
$ref2mid += $_ foreach @ordRef2Pos;
$ref1mid = ($ref1mid/@ordRef1Pos)+$ordRef1Pos[0];
$ref2mid = ($ref2mid/@ordRef2Pos)+$ordRef2Pos[0];
my $alignPad = ceil(abs($ref1mid-$ref2mid)/2);
if ($ref1Len < $ref2Len){
	$ref1AlignPad = ceil($alignPad);
}
else{
	$ref2AlignPad = ceil($alignPad);
}
print "alignpad=$alignPad\n";
print "ref1end=$ordRef1Pos[@ordRef1Pos-1], ref1beg=$ordRef1Pos[0], ref2end=$ordRef2Pos[@ordRef2Pos-1], ref2beg=$ordRef2Pos[0]\n";


foreach my $track (@trackOrder){
	$current_track_position += $pad_top;
	my $glyph = $trackConfigs->{$track}->{'glyph'};
	$current_track_position = &plotTrack ($track,$glyph,$current_track_position);
}

my $outfile = $opt{'o'};
open (IM,">$outfile") or die "Can't open $outfile\n";
print IM $img->png;


#foreach my $track (keys %{$trackData}){
#	print $track."\n";
#	foreach my $k (keys %{$trackData->{$track}}){
#		print "\t$k\n";
#	}
#	print "\t\t".join(":",keys %{$trackData->{$track}->{'G2Tmaps'}})."\n";
#	my $g2tmap=$trackData->{$track}->{'G2Tmaps'}->{'g2t'};
#	my @sorted = sort{$a<=>$b} (keys %{$g2tmap});
#	
#	
#}




#########################################################
# Start Subroutines                                     #
#########################################################






sub plotTrack {
	my $tr = shift;
	my $glyph = shift;
	my $currTrackPos = shift;
	print "Plotting $tr\n";
	$glyph = "" if !defined($glyph);
	if ($tr eq "REF1"){
		print "gothere\n";
		$currTrackPos += 20;
		$img->penSize(0.5,0.5);
		$img->bgcolor('yellow');
		$img->fgcolor('black');
		my $ref1Name = $trackConfigs->{'REF1'}->{'gffName'};
		my $ref2Name = $trackConfigs->{'REF2'}->{'gffName'};
		my @ref1Positions = @{$trackData->{'REF1'}->{'positionArray'}};
		my @ref2Positions = @{$trackData->{'REF2'}->{'positionArray'}};
		my $ref1Len = $trackData->{'REF1'}->{'length'};
		my $ref2Len = $trackData->{'REF2'}->{'length'};
		my ($x1,$y1) = ($ref1AlignPad,$currTrackPos+20);
		my $refHeight = $glyph_height * 2;
		my $poly = new GD::Polygon;
		my $y2 = ($y1 + ($refHeight / 2));
		my $y3 = $y1 + $refHeight;
		my $x2 = $x1+$ref1Len-1;
		$poly->addPt($x1,$y1);
		$poly->addPt($x2-5,$y1);
		$poly->addPt($x2,$y2);
		$poly->addPt($x2-5,$y3);
		$poly->addPt($x1,$y3);
		$img->polygon($poly);
		
		$y1 += $refHeight+1;
		
	
		foreach my $k (keys %{$alignMatrix}){
			if ($alignMatrix->{$k}->{'conserved'} == 1){
				$img->fgcolor('black');
			}
			else{
				$img->fgcolor('gray');
			}
			#print "drawing $k, $y1 to ".$alignMatrix->
			
			$img->moveTo($k+$ref1AlignPad,$y1);
			$img->lineTo($ref2AlignPad + $alignMatrix->{$k}->{'pos'},$y1+($refHeight*2));
		}
		
		$poly = "";
		$x1 = $ref2AlignPad;
		$y1 += ($refHeight*2)+1;
		$poly = new GD::Polygon;
		$y2 = ($y1 + ($refHeight / 2));
		$y3 = $y1 + $refHeight;
		$x2 = $x1+$ref2Len-1;
		$poly->addPt($x1,$y1);
		$poly->addPt($x2-5,$y1);
		$poly->addPt($x2,$y2);
		$poly->addPt($x2-5,$y3);
		$poly->addPt($x1,$y3);
		$img->polygon($poly);
		
		$currTrackPos = $y3;
		
	}
	
	
	elsif($glyph =~ /box/){
		if ($trackConfigs->{$tr}->{'color'}){
			$img->bgcolor($trackConfigs->{$tr}->{'color'});
		}
		else {
			$img->bgcolor('blue');
		}
		$img->fgcolor('black');
		my $refTrack = $trackConfigs->{$tr}->{'reference'};
		if ($params->{'alignType'} eq "transcript" && $trackConfigs->{$tr}->{'mapRef'} eq "genome"){
			my $exons = $trackData->{$refTrack}->{'positionArray'};
			#foreach my $e (@{$exons}){
			#	foreach my $field (keys %{$e}){
			#		print "$field=$e->{$field}:";
			#	}
			#	print "\n";
			#}
			
			my @plotThese = @{$trackData->{$tr}->{'positionArray'}};
			my ($y1) = $currTrackPos+20;
			
			
			foreach my $pt (@plotThese){
				#foreach my $p (keys %{$pt}){
				#	print "$p=".$pt->{$p}.":";
				#}
				#print "\n";
				foreach my $exon (@{$exons}){
					my $g2t = $trackData->{$refTrack}->{'G2Tmaps'}->{'g2t'};
					my $exonStart = $exon->{'start'};
					my $exonEnd = $exon->{'end'};
					my $boxStart = $pt->{'start'};
					my $boxEnd = $pt->{'end'};
					#print "pre es=$exonStart, bs=$boxStart, ee=$exonEnd, be=$boxEnd\n";
					if ($exonStart<$boxStart && $exonEnd>$boxEnd){
						my $x1 = $g2t->{$boxStart};
						my $x2 = $g2t->{$boxEnd};
						if ($trackConfigs->{$tr}->{'reference'} eq 'REF1'){
							$x1 += $ref1AlignPad;
							$x2 += $ref1AlignPad
						}
						else{
							$x1 += $ref2AlignPad;
							$x2 += $ref2AlignPad
						}
						if ($x1 > $x2){
							$img->rectangle($x2,$y1,$x1,$y1+$glyph_height);	
						}
						else{
							$img->rectangle($x1,$y1,$x2,$y1+$glyph_height);	
						}
					}
					elsif($exonStart<$boxStart && $exonEnd>$boxEnd){
						print "overlap1\n";
					}
					elsif($exonStart<$boxStart && $exonEnd>$boxEnd){
						print "overlap2\n";
					}
					else{
						#print "suxor es=$exonStart, bs=$boxStart, ee=$exonEnd, be=$boxEnd\n";
					}
					
				}
				
				#foreach my $k (keys %{$pt}){
				#	
				#	print "$k=$pt->{$k}:";
				#}
				#print "\n";
			}
		}

		$currTrackPos = $glyph_height + 20;
	
	}
	
	elsif($glyph=~/hist/){
		my $axis = (($track_height / 2) + $currTrackPos);
		$img->penSize(1,1);
		$img->bgcolor('black');
		$img->fgcolor('black');
		$img->moveTo(1,$axis);
		$img->lineTo($iwidth,$axis);
		# Draw y-axis
		$img->moveTo($iwidth,$current_track_position);
		$img->lineTo($iwidth,($current_track_position + $track_height));
		# Top tick
		$img->moveTo($iwidth,$current_track_position);
		$img->lineTo(($iwidth + $tickLength),$current_track_position);
		## Middle tick
		$img->moveTo($iwidth,$axis);
		$img->lineTo(($iwidth + $tickLength),$axis);
		# Bottom tick
		$img->moveTo($iwidth,($current_track_position + $track_height));
		$img->lineTo(($iwidth + $tickLength),($current_track_position + $track_height));
		
		$img->penSize(2,2);
		my @tData = @{$trackData->{$tr}->{'positionArray'}};
		print "HISTOGR\n";
		my $line = $tData[0];
		foreach (keys %{$line}){
			print "$_=$line->{$_}:";
		}
		print join("attrib:", keys %{$line->{'attrib'}});
		print "\n";
		$line=$tData[1];
		foreach (keys %{$line}){
			print "$_=$line->{$_}:";
		}
		print "\n";
		my $refTrack = $trackConfigs->{$tr}->{'reference'};
		my $g2t = $trackData->{$refTrack}->{'G2Tmaps'}->{'g2t'};
		foreach my $line (@tData) {
			
			#my ($chrom, $source, $type, $start_pos, $end_pos, $reads, $strand, $blank, $note) = split /\t/, $line;
			my $pos = $line->{'start'};
			
			if ($g2t->{$pos}) {
				my $transcriptPos = $g2t->{$pos};
				my $sizeClass = $line->{'attrib'}->{'sizeClass'};
				my $reads = $line->{'attrib'}->{'reads'};
				my $color = $color{$sizeClass};
				my $strand = $line->{'strand'};
				if ($reads > $read_max) {
					$reads = $read_max;
				} elsif ($reads < $read_min) {
					$reads = $read_min;
				}
				#my $x = (($start_pos - $chromTable{$species1}->{'start'}) * $scale);
				#my $x = (($start_pos - $chromTable{$species1}->{'start'}) * $scale) + $tickLength;
				my $x = $transcriptPos;
				$x += $trackConfigs->{$tr}->{'reference'} eq 'REF1' ? $ref1AlignPad : $ref2AlignPad;
				my $y;
				if ($strand eq '+') {
					$y = ($axis - ($reads * $read_scale))
				} else {
					$y = ($axis + (abs($reads) * $read_scale));
				}
				$img->bgcolor($color);
				$img->fgcolor($color);
				$img->moveTo($x,$axis);
				$img->lineTo($x,$y);
			}
		
		}
		
		
		$currTrackPos += $glyph_height;
	}
	
	else{
		
	}
	
	return $currTrackPos
}
		
	


sub getAlignMatrix{
	#my $tracksRef = shift;
	#my $settings = shift;
	my $ref1 = $trackConfigs->{'REF1'}->{'gffName'};
	my $ref2 = $trackConfigs->{'REF2'}->{'gffName'};
	open (AF,$opt{'A'}) or die "Can't open $opt{'A'}\n";
	my ($alignment,$order) = loadFasta(\*AF);
	my $ref1Count=0;
	my $ref2Count=0;
	my %matrix;
	my @tempRef = keys %{$alignment};
	my $len = length($alignment->{$tempRef[0]});
	for my $i (0..($len-1)){
		my $ref1Letter = substr($alignment->{$ref1},$i,1);
		my $ref2Letter = substr($alignment->{$ref2},$i,1);
		
		$ref1Count++ if $ref1Letter !~ /-/;
		$ref2Count++ if $ref2Letter !~ /-/;
		#print "len=$len, t1L=$taxa1Letter, t2L=$taxa2Letter, t1C=$taxa1Count, t2C=$taxa2Count\n";
		if ($ref1Letter !~ /-/ && $ref2Letter !~ /-/){
			$matrix{$ref1Count}->{'pos'}=$ref2Count;
			if ($ref1Letter eq $ref2Letter){
				$matrix{$ref1Count}->{'conserved'}=1;
			}
			else{
				$matrix{$ref1Count}->{'conserved'}=0;
			}
		}
	}
	my $refLen = $ref1Count > $ref2Count ? $ref1Count : $ref2Count;
	return (\%matrix,$alignment,$refLen);
	
}



#this must return a hash with at least the following:  seqid, start, end, score, strand, and attribs;
sub getData{
	my $trackConfRef = shift;
	my $passedTracks = shift;
	my (%tData,$positionData);
	
	foreach my $track (@{$passedTracks}){
		print "Getting data for $track\n";
		if ($track=~/REF/){
			my $geneLen=0;
			if ($trackConfRef->{$track}->{'mapType'} =~ /gff/i){
				my $gffFile = $trackConfRef->{$track}->{'gffSource'};
				my $gffName = $trackConfRef->{$track}->{'gffName'};
				my $gffField = $trackConfRef->{$track}->{'gffField'};
				$positionData = &readGFF($gffFile,$gffName,$gffField,$track,$trackConfRef);
			}
			
			my ($tempMaps,$highlow) = &makeGtoTmap($positionData,$track,$trackConfRef);
			$tData{$track}->{'G2Tmaps'} = $tempMaps;
			$tData{$track}->{'high'} = $highlow->{'high'};
			$tData{$track}->{'low'} = $highlow->{'low'};
			
			#print "highLow=$tData{$track}->{'low'}, $tData{$track}->{'high'}\n";
			foreach my $pd (@{$positionData}){
				foreach (keys %{$pd}){
					print "$_=$pd->{$_}:";
					
				}
				print "\n";
				$geneLen += $pd->{'end'}-$pd->{'start'}+1;
				
			}
			print "$track GENELEN = $geneLen\n";
			$tData{$track}->{'length'} = $geneLen;
		}
		
		else{
			if ($trackConfRef->{$track}->{'mapType'} =~ /gff/i){
				my $gffFile = $trackConfRef->{$track}->{'gffSource'};
				my $gffName = $trackConfRef->{$track}->{'gffName'};
				my $gffField = $trackConfRef->{$track}->{'gffField'};
				$positionData = &readGFF($gffFile,$gffName,$gffField,$track,$trackConfRef);
			}
			
			elsif($trackConfRef->{$track}->{'mapType'} =~/sRNAdb/i){
				my $ref = $trackConfRef->{$track}->{'reference'};
				my $cashxID = $trackConfRef->{$track}->{'cashxID'};
				my $libs = $trackConfRef->{$track}->{'libraries'};
				$positionData = &readCashxDb($track,$ref,$cashxID,$libs);
				
			}
			
			
		}
		
		if (@{$positionData}==0){
			die "Can't find data for $track\n";
		}
		else{
			print "Returning ".@{$positionData}." for track $track\n";
			#if (@{$positionData} < 30){
			#	foreach my $feat (@{$positionData}){
			#		foreach my $k (keys %{$feat}){
			#			print "$k=$feat->{$k}: ";
			#		}
			#		print "\n";
			#	}
			#}
		}
		
		
		$tData{$track}->{'positionArray'} = $positionData;	
	}
	
	
	return \%tData;
}


sub readGFF {
	my $gFile = shift;
	my $gName = shift;
	my $gField = lc(shift);
	my $track = shift;
	my $conf = shift;
	my @retArray;
	open (GF,$gFile) or die "Can't open $gFile\n";
	while (my $line = <GF>){
		chomp $line;
		next if $line=~/#/;
		next if $line =~ /^[\n\r]+$/;
		my @sLine = split("\t",$line);
		
		
		#if there are attributes, put them into a data structure
		#some attribute types contain more than one entry (e.g. Name=A,B), which is also handled here
		if ($sLine[8] ne '.'){
			my %attribs;
			my @tempSplit = split(';',$sLine[8]);
			foreach my $t (@tempSplit){
				$t=~/([^=]+)=(.*)/;
				my ($aName,$aVal) = ($1,$2);
				if ($aVal=~/[,:]/){
					my @valArray = split(/[,:]/,$aVal);
					$attribs{$aName}=\@valArray;
				}
				else{
					$attribs{$aName} = $aVal;
				}
				
			}
			$sLine[8] = \%attribs;
		}
		
		my %dataHash;
		for (my $i = 0; $i < 9;$i++){
			$dataHash{$gffFields[$i]}=$sLine[$i];
		}
		
		
		my $filterCount = &filterName(\%dataHash,$gName,$gField,$track);
		if ($track =~ /REF/ && $dataHash{'type'} ne "CDS"){
			$filterCount++;
		}
		if ($track!~/REF/){
			$filterCount += &filterPosition(\%dataHash,$track);
		}
		
		
		push(@retArray,\%dataHash) if $filterCount == 0;
	
	}
	
	return \@retArray;
	
	
}

sub readCashxDb{
	my $track = shift;
	my $ref = shift;
	my $cashxID = shift;
	my $libList = shift;
	
	
	my $highPos = $trackData->{$ref}->{'high'};
	my $lowPos = $trackData->{$ref}->{'low'}-25;
	my $seqid = $trackData->{$ref}->{'positionArray'}->[0]->{'seqid'};
	$seqid =~ /(\d+)/;
	my $chrom = $1;
	
	print STDERR " Getting small RNA reads for $track track\n";
	my $ReadCASHX1 = new ReadCASHX(conf => $conf_file, species => $cashxID);
	
	#get library information
	my (%libDb,%libReadCount);
	$libReadCount{'total'} = 0;
	$ReadCASHX1->query("generic_select", "*", "library_list");
	while (my $row = $ReadCASHX1->results("hash")){
		$libDb{$row->{'library_id'}} = $row;
	}
	
	foreach my $l (split (",",$libList)){
		if ($libDb{$l}){
			if ($libDb{$l}->{'total_reads'}+0 == 0){
				print "The total read count from library $l is zero, I'll ignore it\n";
			}
			else {
				$libReadCount{$l} = $libDb{$l}->{'total_reads'};
				$libReadCount{'total'} += $libReadCount{$l}; 
			}
		}
		else{
			print STDERR "Library $l for $cashxID is not in the database, I'll ignore it\n";
			
		}
	}
	
	if (keys %libReadCount == 0){
		die "No valid libraries selected for $track, I'm melting\n";
	}
	
	
	my @hitLines;
	for (my $p=$lowPos;$p<=$highPos;$p++){
		$ReadCASHX1->query("generic_select", "*", "HitGenome WHERE hit_Start =  '$p'");
		while (my $row = $ReadCASHX1->results("hash")) {
			push(@hitLines,$row);
			
		}
	}
	#print "count=".@hitLines."\n";
	my (%chromFilteredHits,@seqids);
	foreach my $h (@hitLines){
		if ($h->{'hit_chromNum'} == $chrom){
			$chromFilteredHits{$h->{'seq_id'}} = $h;
		}
	}
	#print "count srna chromfilt=".(keys %chromFilteredHits)."\n";
	
	my $readCounts=0;
	foreach my $c (keys %chromFilteredHits){
		my $selectText = "unapproved,unapproved_reads WHERE unapproved.sid = unapproved_reads.sid and seq_id = $c";
		$ReadCASHX1->query("generic_select", "unapproved.seq_id,unapproved_reads.reads,unapproved_reads.library_id", $selectText );
		my $hitReads = 0;
		#print "lib143:".$libReadCount{'14}
		while (my $row = $ReadCASHX1->results("hash")) {
			foreach my $k (keys %{$row}){
				#print "key=$k, val=$row->{$k}:";
			}
			#print "\n";
			
			if ($libReadCount{$row->{'library_id'}}){
				$hitReads += $row->{'reads'};
			}
		}
		$chromFilteredHits{$c}->{'reads'} = $hitReads;
	}
	my %readData;
	foreach my $c (keys %chromFilteredHits){
		my $sizeClass = length($chromFilteredHits{$c}->{'hit_seq'});
		my $startPos = $chromFilteredHits{$c}->{'hit_start'};
		for(my $s=$startPos;$s<=$startPos+$sizeClass-1;$s++){
			$readData{$s}->{$sizeClass} += 1;
		}
		
		$readCounts += $chromFilteredHits{$c}->{'reads'};
	}
	
	my @retArray;
	foreach my $pos(keys %readData){
		foreach my $class (keys %{$readData{$pos}}){
			
			my %retHash = ('seqid'=>$chrom,
						   'start' => $pos,
						   'end' => $pos,
						   'score' => 0,
						   'strand' => 0);
			
			my %attrib = ('sizeClass'=>$class,'reads'=>$readData{$pos}->{$class});
			$retHash{'attrib'} = \%attrib;
			push (@retArray,\%retHash);
		}
		
		
	}
	
	#foreach my $r (@retArray){
	#	foreach my $k (keys %{$r}){
	#		if ($k eq "attrib"){
	#			foreach $a (keys %{$r->{$k}}){
	#				print "$a=$r->{$k}->{$a}:";
	#			}
	#		}
	#		else{
	#			print "$k=$r->{$k}:";
	#		}
	#	}
	#	print "\n";
	#}
	
	return \@retArray;
	

}


sub makeGtoTmap {
	my @data = @{(shift)};
	my $track = shift;
	my $conf = shift;
	
	my (%G2T,%T2G,$high,$low);
	my $strand = $data[0]->{'strand'};
	my $transcriptPos = 1;
	if ($strand eq "+"){
		@data = sort {$a->{'start'}<=>$b->{'start'}} @data;
		foreach my $d (@data){
			next if $d->{'type'} ne "CDS";
			for (my $i=$d->{'start'};$i<=$d->{'end'};$i++){
				$G2T{$i}=$transcriptPos;
				$T2G{$transcriptPos} = $i;
				$transcriptPos++;
			}
		}
	}
	else{
		@data = sort {$b->{'start'}<=>$a->{'start'}} @data;
		#print "Negmakemaptrack=$track\n";
		foreach my $d (@data){
			next if $d->{'type'} ne "CDS";
			for (my $i=$d->{'end'};$i>=$d->{'start'};$i--){
				$G2T{$i}=$transcriptPos;
				$T2G{$transcriptPos} = $i;
				$transcriptPos++;
			}
		}
	}
	
	my @sorted = sort {$a<=>$b} (keys %G2T);
	
	my (%retHash1,%retHash2);
	$retHash1{'g2t'} = \%G2T;
	$retHash1{'t2g'} = \%T2G;
	$retHash2{'high'} = $sorted[@sorted-1];
	$retHash2{'low'} = $sorted[0];
	return (\%retHash1,\%retHash2)
}




sub sortCDS{
	
}


#this allows data imports that contain information for more than just the features of interest
#this subroutine is responsible for allowing only those features through that are specified in the conf file

sub filterName {
	my $lineRef = shift;
	my $gName = shift;
	my $gField = shift;
	my $track = shift;
	
	
	#check to see if the name given in the conf file matches 
	if ($gField =~ /attrib/){
		if ($lineRef->{'attribs'} eq '.'){
			return 1;
		}
		else{
			foreach my $attrib (values %{$lineRef->{'attribs'}}){
				#print "ref=".ref($attrib)."\n";
				if (ref($attrib) eq "ARRAY"){
					foreach my $a (@{$attrib}){
						return 0 if $a eq $gName;
					}
				}
				else{
					return 0 if $attrib eq $gName;
				}
			}
			
			return 1;
		}
	}
	else{
		if ($lineRef->{$gField}=~/$gName/){
			return 0;
		}
		else{
			return 1;
		}
	}
	
	#make sure that the non-ref features are overlaping the genomic positions of the reference gene
	
}

sub filterPosition {
	my $lineRef = shift;
	my $track = shift;
	
	my $refTrack = $trackConfigs->{$track}->{'reference'};
	my $refHigh = $trackData->{$refTrack}->{'high'};
	my $refLow = $trackData->{$refTrack}->{'low'};
	$trackData->{$refTrack}->{'positionArray'}->[0]->{'seqid'}=~/(\d+)/;
	my $refChrom = $1;
	
	#print "filtering gene overlaps for $track\n";
	if (($lineRef->{'start'} < $refLow && $lineRef->{'end'}> $refLow) ||
		($lineRef->{'start'} < $refHigh && $lineRef->{'end'} > $refHigh) ||
		($lineRef->{'start'} > $refLow && $lineRef->{'end'} < $refHigh))
	{
		#print "low=$low, high=$high, tps=$tp->{'start'}, tpe=$tp->{'end'}\n";
			$lineRef->{'seqid'}=~/(\d+)/;
			my $boxChrom = $1;
			return $boxChrom == $refChrom ? 0 : 1;
	}
	else{
		return 1;
	}
			
	

}

sub getPlotCode{
	my $seq = shift;
	my $tID = shift;
	#print "seq=$seq, tID=$tID\n";
	my $code;
	if ($tID =~ /REF*/){
		$seq =~ s/-//g;
		$code = "B".length($seq);
	}
	return $code;
	
}



sub loadFasta {
	my $fh = shift;
	my %returnHash;
	my $header="";
	my $seq="";
	my @order;
	while (my $line = <$fh>){
		next if $line =~ /^#/;
		next if $line =~ /^[\n\r]+$/;
		chomp $line;
		if ($line=~/>(\S+)/){
			my $newHeader = $1;
			push (@order,$newHeader);
			if ($seq ne ""){
				$returnHash{$header} = $seq;
				$seq = "";
			}
			$header = $newHeader;
		}
		elsif (eof($fh)){
			$returnHash{$header}=$seq.$line;
		}
		else {
			$seq .= $line;
		}
	}
	return (\%returnHash,\@order);
}


sub round {
	my $num = shift;
	if ($num =~ /\d+\.(\d)/) {
		if ($1 >= 5) {
			$num = ceil($num);
		} else {
			$num = floor($num);
		}
	}
	return $num;
}




sub var_check {
	my $errors = "";
	
	if ($opt{'L'}) {
		$alignment = $opt{'L'};
	} else {
		$errors .=  "  ERROR: Can't open conf file (-L).\n";
	}
	
	if ($opt{'A'}) {
		$alignment = $opt{'A'};
	} else {
		$errors .=  "  ERROR: Can't open alignment fasta file (-A).\n";
	}
=begin
	if ($opt{'p'}) {
		$svgFile = $opt{'p'};
	} else {
		$errors .=  "  ERROR: Plot file prefix not provided.\n";
		
	}
	if ($opt{'c'}) {
		$chromNum = $opt{'c'};
	} else {
		$errors .=  "  ERROR: Chromosome number not provided.\n";
	}
	if ($opt{'s'}) {
		$start = $opt{'s'};
	} else {
		$errors .=  "  ERROR: Start coordinate not provided.\n";
	}
	if ($opt{'e'}) {
		$end = $opt{'e'};
	} else {
		$errors .=  "  ERROR: End coordinate not provided.\n\n";
	}
	if ($opt{'A'}) {
		$alignment = $opt{'A'};
	} else {
		$errors .=  "  ERROR: An alignment code was not provided.\n";
	}
	if ($opt{'C'}) {
		$conf_file = $opt{'C'};
	} else {
		$errors .=  "  ERROR: Conf file not provided.\n";
	}
	if ($opt{'S'}) {
		$refSpecies = $opt{'S'};
	} else {
		$errors .=  " ERROR: Reference species not provided.\n";
	}
	if ($opt{'w'}) {
		$window = $opt{'w'};
	} else {
		$window = 100;
	}
	if ($opt{'o'}) {
		$step = $opt{'o'};
	} else {
		$step = 1;
	}
	if ($opt{'h'}) {
		&var_error();
	}
=cut
	if ($errors ne ""){
		print $errors."\n";
		&var_error()
	}
	
} #end var_check


sub var_error {
	
	print STDERR <<PRINTTHIS;
This script will create a conservation plot of orthologous regions between two genomes.
Usage:
mercatorPlot.pl -C <conf_file> -L <conf file> -S <ref_species> -A <alignment> -p <plot_file_prefix> -c <chrom> 

-C   The CASHX configuration file.

-L   The alignment configuration file.

-S   The plotting reference species.
example: -S A_THALIANA

-A   The alignment code from 'mercator.conf'.
example: -A ATH_ALY

-p   The plot file prefix.

-c   The reference species chromosome.

-w   The window size used to calculate conservation. (DEFAULT = 100)

-o   The scroll step size. (DEFAULT = 1)

-h   Print this menu.


PRINTTHIS
	exit 0;
}

#########################################################
# End of Varriable error Subroutine "var_error"         #
#########################################################
