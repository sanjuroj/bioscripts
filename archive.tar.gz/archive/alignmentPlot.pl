#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Std;
use GD::Simple;
use Config::Tiny;

my %opts;
getopts('c:o:',\%opts); 

&varcheck;
open (OUT,">$opts{'o'}") or die "Can't open $opts{'o'}\n";

#get and process config file
my $config = Config::Tiny->read($opts{'c'});
my ($tracks,$cSettings);
my @trackOrder;
foreach my $c (keys %{$config}){
	if ($c ne "_"){
		$tracks->{$c} = $config->{$c} if $c ne "_";
		push(@trackOrder,$c);
	}
}

$cSettings = $config->{'_'};
print "cSettingskeys=".join(":",keys %{$cSettings})."\n";
my $refType = $cSettings->{'refType'};
@trackOrder = sort {$tracks->{$a}->{'trackOrder'}<=>$tracks->{$a}->{'trackOrder'}} @trackOrder;

#alignmentMatrix = position mapping; alignment = two sequences; order = original order of sequence
my ($alignMatrix,$alignRef,$alignLen) = getAlignMatrix($tracks,$cSettings);
print "aRefkesy:".join("\n",(keys %{$alignRef}))."\n";

foreach my $t (keys %{$tracks}){
	#print "t=$t\n";
	print "gffname=".$tracks->{$t}->{'gffName'}."\n";
	my $trackName = $tracks->{$t}->{'gffName'};
	#print "tname = $alignRef->{$trackName}\n";
	$tracks->{$t}->{'plotCode'} = getPlotCode($alignRef->{$trackName},$t);
}

print "keys:\n".join((keys %{$tracks}))."\n";
die "Tracks could not be read\n" if (keys %{$tracks} == 0);

#my @keys = sort {$a<=>$b} keys (%{$alignMatrix});
#foreach (@keys){
#	print "key=$_, val=$alignMatrix->{$_}\n";
#}


my $trackCount = keys (%{$tracks});  # transcripts count as tracks
#my $imgWidth = $alignLen+50;
my $imgWidth = 500+$alignLen+50;
my $imgHeight = 100 + $trackCount*30;
my $trackHeight = 10;

my $img = GD::Simple->new($imgWidth,$imgHeight);
$img->fgcolor('red');
$img->bgcolor('red');
$img->penSize(1);
my $hscale = 1;
my $hInset = 20;
my $vInset = 20;
my $h = $hInset;
my $v = $vInset;
$img->moveTo($h*$hscale,$v);

my $code = $tracks->{$trackOrder[0]}->{'plotCode'};
print "g1code=$code\n";
while ($code =~ /(\D+)(\d+)/g){
	my $glyph = $1;
	my $len = $2;
	$img->rectangle($h,$v,$h+$len,$v+$trackHeight);
	
}

$v += $trackHeight+1;
$img->fgcolor('black');
foreach my $k (keys %{$alignMatrix}){
	$img->moveTo($k+$hInset,$v);
	$img->lineTo($alignMatrix->{$k}+$hInset,$v+($trackHeight*4));
	#print "start=".($k+$hInset).",".($v)."\n";
	#print "end=".($alignMatrix->{$k}+$hInset).",".($v+$trackHeight)."\n";
}
$v += $trackHeight*4+1;

$img->fgcolor('red');
$v += $trackHeight+1;
$code = $tracks->{$trackOrder[1]}->{'plotCode'};
print "g2code=$code\n";
while ($code =~ /(\D+)(\d+)/g){
	my $glyph = $1;
	my $len = $2;
	$img->rectangle($h,$v,$h+$len,$v+$trackHeight);
}

#foreach my $t (@trackOrder){
#	
#	$img->moveTo($h*$hscale,$v);
#	$img->lineTo($h*$hscale,$v+30);
#	$h++;
#}




#my $len = 20;
#$img->moveTo($h,$v);
#$img->penSize(5);
#$img->lineTo($h+$len,$v);


#$img->rectangle(5,5,$len,$len);
print OUT $img->png;

sub getPlotCode{
	my $seq = shift;
	my $tID = shift;
	#print "seq=$seq, tID=$tID\n";
	my $code;
	if ($tID =~ /REF*/){
		$seq =~ s/-//g;
		$code = "B".length($seq);
	}
	return $code;
	
}



sub getAlignMatrix{
	my $tracksRef = shift;
	my $settings = shift;
	my $ref1 = $tracksRef->{'REF1'}->{'gffName'};
	my $ref2 = $tracksRef->{'REF2'}->{'gffName'};
	open (AF,$settings->{'alignFile'}) or die "Can't open $settings->{'alignFile'}\n";
	my ($alignment,$order) = loadFasta(\*AF);
	my $ref1Count=0;
	my $ref2Count=0;
	my %matrix;
	my $len = length($alignment->{$ref1});
	for my $i (0..($len-1)){
		my $ref1Letter = substr($alignment->{$ref1},$i,1);
		my $ref2Letter = substr($alignment->{$ref2},$i,1);
		$ref1Count++ if $ref1Letter !~ /-/;
		$ref2Count++ if $ref2Letter !~ /-/;
		#print "len=$len, t1L=$taxa1Letter, t2L=$taxa2Letter, t1C=$taxa1Count, t2C=$taxa2Count\n";
		if ($ref1Letter !~ /-/ && $ref2Letter !~ /-/){
			$matrix{$ref1Count}=$ref2Count;
		}
	}
	my $refLen = $ref1Count > $ref2Count ? $ref1Count : $ref2Count;
	return (\%matrix,$alignment,$refLen);
	
}




sub loadFasta {
	my $fh = shift;
	my %returnHash;
	my $header="";
	my $seq="";
	my @order;
	while (my $line = <$fh>){
		next if $line =~ /^#/;
		next if $line =~ /^[\n\r]+$/;
		chomp $line;
		if ($line=~/>(\S+)/){
			my $newHeader = $1;
			push (@order,$newHeader);
			if ($seq ne ""){
				$returnHash{$header} = $seq;
				$seq = "";
			}
			$header = $newHeader;
		}
		elsif (eof($fh)){
			$returnHash{$header}=$seq.$line;
		}
		else {
			$seq .= $line;
		}
	}
	return (\%returnHash,\@order);
}



sub varcheck {
	my $errors = "";
	if (!$opts{'o'}){
		$errors .= "-o flag not provided\n";
	}
	
	if (!$opts{'c'}){
		$errors .= "-c flag not provided\n";
	}
	elsif(!(-e $opts{'c'})) {
		$errors .= "Can't open $opts{'c'}\n";
	}
	
	
	if ($errors ne "") {
		print "\n$errors";
		&usage;
	}
}

sub usage{
	
	my $scriptName = $0;
	$scriptName =~ s/\/?.*\///;
	
	print "\nusage: perl $scriptName <-o output file> <-c file>\n";
print <<PRINTTHIS;

-c is the config file for the tracks 
	
PRINTTHIS
	exit;
}